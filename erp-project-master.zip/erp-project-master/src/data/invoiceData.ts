export const invoiceData = [
  {
    id: 1,
    name: "Ade",
    email: "ade@gmail.com",
    phone: "08123456789",
    landlord: "Mr Taiwo",
    amount: 12320,
  },
  {
    id: 2,
    name: "Kola",
    email: "kola@gmail.com",
    phone: "08123456789",
    landlord: "Mr Taiwo Philips",
    amount: 12320,
  },
  {
    id: 3,
    name: "Martins",
    email: "martins@gmail.com",
    phone: "08123456789",
    landlord: "Mr Kehinde",
    amount: 12320,
  },
];
